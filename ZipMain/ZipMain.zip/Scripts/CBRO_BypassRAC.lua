-- Written by turtletowerz (Turtle#8748 on Discord). CREDITS: Rerumu for the Elysian Decompiler
local services = {'Workspace', 'ReplicatedFirst', 'ReplicatedStorage', 'Lighting', 'StarterGui', 'StarterPack', 'StarterPlayer', 'Teams', 'InsertService'}
local ignore = {CameraScript=true, ControlScript=true, ChatScript=true, BubbleChat=true}
local places = {}
for i, v in next, services do table.insert(places, game:GetService(tostring(v))) end
for i, z in pairs(game:GetService'Players':GetPlayers()) do if z ~= game:GetService'Players'.LocalPlayer then ignore[z.Name] = true end	end
local scrtodecompile = {}
wait(0.25)

local GetNil
local Decompile
local WriteFile

if elysianexecute then
	GetNil = function() return getnilinstances() end
	Decompile = function(s) local A, B = decompile(s, 'unluac') if A then A = A:gsub('\r+', '') wait() end return A, B end
	WriteFile = function(name, str) return writefile(name, str) end
elseif syn then
	GetNil = function() return getnilinstances() end
	Decompile = function(s) return decompile(s) end
	WriteFile = function(name, str) return writefile(name, str) end
elseif PROTOSMASHER_LOADED then
	GetNil = function() return get_nil_instances() end
	Decompile = function(s) return decompile(s) end
	WriteFile = function(name, str) return writefile(name, str) end
else
	warn('Exploit is not Synapse or Elysian')
end

if type(GetNil) ~= nil then -- Kinda ironic
	-- There has to be a better way to check this
	local function DescendantOfService(itm)  for i, p in next, places do if itm:IsDescendantOf(p) then return true end end return false end

	local function CollectScripts(place)
		local isnil = (place == nil)
		local child = (isnil and GetNil() or place:GetChildren())

		for i, v in next, child do
			if (v:IsA'ModuleScript' or v:IsA'LocalScript') and not ignore[v.Name] and (not string.find(v:GetFullName(), "game.Core") or not string.find(v:GetFullName(), "NIL.Core")) then
				table.insert(scrtodecompile, v) -- Lazy method for fixing the names
			end
			if not ignore[v.Name] then -- To make sure you get all scripts, but not descendants of ignored ones
				CollectScripts(v)
			end
		end
	end

	for i, z in next, places do CollectScripts(z) end -- Basic Services
	CollectScripts(nil) -- Nil Instances
	wait(0.25)

	local saved_decompiles = {}

	for i, x in next, scrtodecompile do
		local source = Decompile(x)
		local add = 0

		if #saved_decompiles >= 1 then
				for i,v in pairs(saved_decompiles) do
						if not tostring(v) == tostring(source) and i == x.Name then
								add = add + 1
						end
				end
		else
				saved_decompiles[tostring(x.Name)] = tostring(source)
		end

		local header = DescendantOfService(x) and 'game.' or 'NIL.'
		local location, name = '-- Script Location: ' .. header .. x:GetFullName() .. '\n', tostring(x.Name)
		if add >= 1 then
				WriteFile(name .. '_MANDATORYADDITION_' .. tostring(add) .. '.txt', (location .. source))
		else
				WriteFile(name .. '.txt', (location .. source))
		end
		add = 0
		wait()
	end
end
