for i,v in next, debug.getregistry() do
   if type(v) == 'function' then
       local s, yo = pcall(function() return debug.getupvalues(v) end)
       if yo and type(yo) == 'table' then
           if yo.Attributes then
               local hi = yo.Attributes;
               hi.freethrow = math.huge;
               hi.postscorer = math.huge;
               hi.ballspeed  = 70;
               hi.jump = 50;
               hi.steal = math.huge;
               hi.shotcontest = 0;
               hi["2pointer"] = math.huge;
               hi["3pointer"] = math.huge;
               hi.passing = math.huge;
               hi.layup = math.huge;
               hi.strength = math.huge;
               hi.dunk = math.huge;
               hi.speed = 75;
               hi.handles = math.huge;
               hi.movingshot = math.huge;
               hi.defense = math.huge;
               hi.stamina = math.huge;
           end;
       end;
   end;
end;

print("loaded")