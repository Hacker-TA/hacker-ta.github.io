function CreateGUI()
local NewGuiPart1 = Instance.new("ScreenGui")
NewGuiPart1.Name = "Linx"
NewGuiPart1.Parent = game.Players.LocalPlayer.PlayerGui
-------
local NewGuiPart2 = Instance.new("Frame")
NewGuiPart2.Active = true
NewGuiPart2.BackgroundColor3 = Color3.new(0.294118, 0.294118, 0.294118)
NewGuiPart2.BorderSizePixel = 0
NewGuiPart2.Name = "MainFrame"
NewGuiPart2.Position = UDim2.new(0.5, -200, 0.5, -100)
NewGuiPart2.Size = UDim2.new(0, 400, 0, 200)
NewGuiPart2.Draggable = true
NewGuiPart2.Parent = NewGuiPart1
-------
local NewGuiPart3 = Instance.new("Frame")
NewGuiPart3.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart3.BackgroundTransparency = 1
NewGuiPart3.BorderSizePixel = 0
NewGuiPart3.Name = "ServerTab"
NewGuiPart3.Size = UDim2.new(0, 400, 0, 200)
NewGuiPart3.Parent = NewGuiPart2
-------
local NewGuiPart4 = Instance.new("TextButton")
NewGuiPart4.Active = true
NewGuiPart4.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart4.BorderSizePixel = 0
NewGuiPart4.Name = "LagButton"
NewGuiPart4.Position = UDim2.new(0.063000001, 0, 0.550000012, 0)
NewGuiPart4.Selectable = true
NewGuiPart4.Size = UDim2.new(0, 100, 0, 25)
NewGuiPart4.Style = Enum.ButtonStyle.Custom
NewGuiPart4.Font = Enum.Font.SourceSansLight
NewGuiPart4.FontSize = Enum.FontSize.Size18
NewGuiPart4.Text = "Lag"
NewGuiPart4.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart4.TextWrapped = true
NewGuiPart4.Parent = NewGuiPart3
-------
local NewGuiPart5 = Instance.new("TextButton")
NewGuiPart5.Active = true
NewGuiPart5.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart5.BorderSizePixel = 0
NewGuiPart5.Name = "GodButton"
NewGuiPart5.Position = UDim2.new(0.063000001, 0, 0.252000004, 0)
NewGuiPart5.Selectable = true
NewGuiPart5.Size = UDim2.new(0, 100, 0, 25)
NewGuiPart5.Style = Enum.ButtonStyle.Custom
NewGuiPart5.Font = Enum.Font.SourceSansLight
NewGuiPart5.FontSize = Enum.FontSize.Size18
NewGuiPart5.Text = "God"
NewGuiPart5.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart5.TextWrapped = true
NewGuiPart5.Parent = NewGuiPart3
-------
local NewGuiPart6 = Instance.new("TextButton")
NewGuiPart6.Active = true
NewGuiPart6.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart6.BorderSizePixel = 0
NewGuiPart6.Name = "KillButton"
NewGuiPart6.Position = UDim2.new(0.063000001, 0, 0.400000006, 0)
NewGuiPart6.Selectable = true
NewGuiPart6.Size = UDim2.new(0, 100, 0, 25)
NewGuiPart6.Style = Enum.ButtonStyle.Custom
NewGuiPart6.Font = Enum.Font.SourceSansLight
NewGuiPart6.FontSize = Enum.FontSize.Size18
NewGuiPart6.Text = "Kill"
NewGuiPart6.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart6.TextWrapped = true
NewGuiPart6.Parent = NewGuiPart3
-------
local NewGuiPart7 = Instance.new("TextBox")
NewGuiPart7.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart7.BorderSizePixel = 0
NewGuiPart7.Name = "NameBox"
NewGuiPart7.Position = UDim2.new(0, 0, 0.899999976, 0)
NewGuiPart7.Size = UDim2.new(0, 400, 0, 20)
NewGuiPart7.Font = Enum.Font.SourceSansLight
NewGuiPart7.FontSize = Enum.FontSize.Size14
NewGuiPart7.Text = ""
NewGuiPart7.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart7.Parent = NewGuiPart3
-------
local NewGuiPart8 = Instance.new("Frame")
NewGuiPart8.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart8.BackgroundTransparency = 1
NewGuiPart8.BorderSizePixel = 0
NewGuiPart8.Name = "SettingsTab"
NewGuiPart8.Size = UDim2.new(0, 400, 0, 200)
NewGuiPart8.Visible = false
NewGuiPart8.Parent = NewGuiPart2
-------
local NewGuiPart9 = Instance.new("TextBox")
NewGuiPart9.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart9.BorderSizePixel = 0
NewGuiPart9.Name = "PrefixBox"
NewGuiPart9.Position = UDim2.new(0.199999988, 0, 0.25, 0)
NewGuiPart9.Size = UDim2.new(0, 20, 0, 25)
NewGuiPart9.Font = Enum.Font.SourceSansLight
NewGuiPart9.FontSize = Enum.FontSize.Size14
NewGuiPart9.Text = "!LX"
NewGuiPart9.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart9.Parent = NewGuiPart8
-------
local NewGuiPart10 = Instance.new("TextLabel")
NewGuiPart10.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart10.BackgroundTransparency = 1
NewGuiPart10.Name = "PrefixLabel"
NewGuiPart10.Position = UDim2.new(0, 0, 0.25, 0)
NewGuiPart10.Size = UDim2.new(0, 100, 0, 25)
NewGuiPart10.Font = Enum.Font.SourceSansLight
NewGuiPart10.FontSize = Enum.FontSize.Size24
NewGuiPart10.Text = "Prefix:"
NewGuiPart10.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart10.Parent = NewGuiPart8
-------
local NewGuiPart11 = Instance.new("Frame")
NewGuiPart11.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart11.BackgroundTransparency = 1
NewGuiPart11.BorderSizePixel = 0
NewGuiPart11.Name = "SpawnerTab"
NewGuiPart11.Size = UDim2.new(0, 400, 0, 200)
NewGuiPart11.Visible = false
NewGuiPart11.Parent = NewGuiPart2
-------
local NewGuiPart12 = Instance.new("Frame")
NewGuiPart12.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart12.BackgroundTransparency = 1
NewGuiPart12.BorderSizePixel = 0
NewGuiPart12.Name = "MiscellaneousTab"
NewGuiPart12.Size = UDim2.new(0, 400, 0, 200)
NewGuiPart12.Visible = false
NewGuiPart12.Parent = NewGuiPart2
-------
local NewGuiPart13 = Instance.new("Frame")
NewGuiPart13.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart13.BorderSizePixel = 0
NewGuiPart13.Name = "HeaderFrame"
NewGuiPart13.Size = UDim2.new(0, 400, 0, 20)
NewGuiPart13.Parent = NewGuiPart2
-------
local NewGuiPart14 = Instance.new("TextLabel")
NewGuiPart14.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart14.BackgroundTransparency = 1
NewGuiPart14.Name = "HeaderLabel"
NewGuiPart14.Size = UDim2.new(0, 400, 0, 20)
NewGuiPart14.Font = Enum.Font.SourceSansLight
NewGuiPart14.FontSize = Enum.FontSize.Size14
NewGuiPart14.Text = "LINX"
NewGuiPart14.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart14.TextScaled = true
NewGuiPart14.TextWrapped = true
NewGuiPart14.Parent = NewGuiPart13
-------
local NewGuiPart15 = Instance.new("TextButton")
NewGuiPart15.Active = true
NewGuiPart15.BackgroundColor3 = Color3.new(0.784314, 0, 0)
NewGuiPart15.BorderSizePixel = 0
NewGuiPart15.Name = "CloseButton"
NewGuiPart15.Position = UDim2.new(0.950833321, 0, -0.100000001, 2)
NewGuiPart15.Selectable = true
NewGuiPart15.Size = UDim2.new(0, 20, 0, 20)
NewGuiPart15.Style = Enum.ButtonStyle.Custom
NewGuiPart15.Font = Enum.Font.SourceSansLight
NewGuiPart15.FontSize = Enum.FontSize.Size14
NewGuiPart15.Text = "X"
NewGuiPart15.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart15.TextScaled = true
NewGuiPart15.TextStrokeColor3 = Color3.new(1, 1, 1)
NewGuiPart15.TextWrapped = true
NewGuiPart15.Parent = NewGuiPart13
-------
local NewGuiPart16 = Instance.new("Frame")
NewGuiPart16.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart16.BackgroundTransparency = 1
NewGuiPart16.BorderSizePixel = 0
NewGuiPart16.Name = "TabFrame"
NewGuiPart16.Position = UDim2.new(0, 0, 1, 0)
NewGuiPart16.Size = UDim2.new(0, 400, 0, 20)
NewGuiPart16.Parent = NewGuiPart13
-------
local NewGuiPart17 = Instance.new("TextButton")
NewGuiPart17.Active = true
NewGuiPart17.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart17.BorderSizePixel = 0
NewGuiPart17.Name = "Server"
NewGuiPart17.Selectable = true
NewGuiPart17.Size = UDim2.new(0, 100, 0, 20)
NewGuiPart17.Style = Enum.ButtonStyle.Custom
NewGuiPart17.Font = Enum.Font.SourceSansLight
NewGuiPart17.FontSize = Enum.FontSize.Size14
NewGuiPart17.Text = "Server"
NewGuiPart17.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart17.Parent = NewGuiPart16
-------
local NewGuiPart18 = Instance.new("TextButton")
NewGuiPart18.Active = true
NewGuiPart18.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart18.BorderSizePixel = 0
NewGuiPart18.Name = "Settings"
NewGuiPart18.Position = UDim2.new(0.75, 0, 0, 0)
NewGuiPart18.Selectable = true
NewGuiPart18.Size = UDim2.new(0, 100, 0, 20)
NewGuiPart18.Style = Enum.ButtonStyle.Custom
NewGuiPart18.Font = Enum.Font.SourceSansLight
NewGuiPart18.FontSize = Enum.FontSize.Size14
NewGuiPart18.Text = "Settings"
NewGuiPart18.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart18.Parent = NewGuiPart16
-------
local NewGuiPart19 = Instance.new("TextButton")
NewGuiPart19.Active = true
NewGuiPart19.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart19.BorderSizePixel = 0
NewGuiPart19.Name = "Miscellaneous"
NewGuiPart19.Position = UDim2.new(0.5, 0, 0, 0)
NewGuiPart19.Selectable = true
NewGuiPart19.Size = UDim2.new(0, 100, 0, 20)
NewGuiPart19.Style = Enum.ButtonStyle.Custom
NewGuiPart19.Font = Enum.Font.SourceSansLight
NewGuiPart19.FontSize = Enum.FontSize.Size14
NewGuiPart19.Text = "Miscellaneous"
NewGuiPart19.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart19.Parent = NewGuiPart16
-------
local NewGuiPart20 = Instance.new("TextButton")
NewGuiPart20.Active = true
NewGuiPart20.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart20.BorderSizePixel = 0
NewGuiPart20.Name = "Spawner"
NewGuiPart20.Position = UDim2.new(0.25, 0, 0, 0)
NewGuiPart20.Selectable = true
NewGuiPart20.Size = UDim2.new(0, 100, 0, 20)
NewGuiPart20.Style = Enum.ButtonStyle.Custom
NewGuiPart20.Font = Enum.Font.SourceSansLight
NewGuiPart20.FontSize = Enum.FontSize.Size14
NewGuiPart20.Text = "Spawner"
NewGuiPart20.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart20.Parent = NewGuiPart16
-------
local NewGuiPart21 = Instance.new("Frame")
NewGuiPart21.Active = true
NewGuiPart21.BackgroundColor3 = Color3.new(0.294118, 0.294118, 0.294118)
NewGuiPart21.BorderSizePixel = 0
NewGuiPart21.Name = "ErrorFrame"
NewGuiPart21.Position = UDim2.new(0.5, -150, 0.5, -75)
NewGuiPart21.Size = UDim2.new(0, 300, 0, 150)
NewGuiPart21.Visible = false
NewGuiPart21.Draggable = true
NewGuiPart21.Parent = NewGuiPart1
-------
local NewGuiPart22 = Instance.new("Frame")
NewGuiPart22.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
NewGuiPart22.BorderSizePixel = 0
NewGuiPart22.Name = "HeaderFrame"
NewGuiPart22.Size = UDim2.new(0, 300, 0, 20)
NewGuiPart22.Parent = NewGuiPart21
-------
local NewGuiPart23 = Instance.new("TextLabel")
NewGuiPart23.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart23.BackgroundTransparency = 1
NewGuiPart23.Name = "HeaderLabel"
NewGuiPart23.Size = UDim2.new(0, 300, 0, 20)
NewGuiPart23.Font = Enum.Font.SourceSansLight
NewGuiPart23.FontSize = Enum.FontSize.Size14
NewGuiPart23.Text = "INFORMATION"
NewGuiPart23.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart23.TextScaled = true
NewGuiPart23.TextWrapped = true
NewGuiPart23.Parent = NewGuiPart22
-------
local NewGuiPart24 = Instance.new("TextButton")
NewGuiPart24.Active = true
NewGuiPart24.BackgroundColor3 = Color3.new(0.784314, 0, 0)
NewGuiPart24.BorderSizePixel = 0
NewGuiPart24.Name = "CloseButton"
NewGuiPart24.Position = UDim2.new(0.93416667, 0, -0.100000001, 2)
NewGuiPart24.Selectable = true
NewGuiPart24.Size = UDim2.new(0, 20, 0, 20)
NewGuiPart24.Style = Enum.ButtonStyle.Custom
NewGuiPart24.Font = Enum.Font.SourceSansLight
NewGuiPart24.FontSize = Enum.FontSize.Size14
NewGuiPart24.Text = "X"
NewGuiPart24.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart24.TextScaled = true
NewGuiPart24.TextStrokeColor3 = Color3.new(1, 1, 1)
NewGuiPart24.TextWrapped = true
NewGuiPart24.Parent = NewGuiPart22
-------
local NewGuiPart25 = Instance.new("TextLabel")
NewGuiPart25.BackgroundColor3 = Color3.new(0.639216, 0.635294, 0.647059)
NewGuiPart25.BackgroundTransparency = 1
NewGuiPart25.BorderSizePixel = 0
NewGuiPart25.Name = "ErrorLabel"
NewGuiPart25.Position = UDim2.new(0, 0, 0.13333334, 0)
NewGuiPart25.Size = UDim2.new(0, 300, 0, 130)
NewGuiPart25.Font = Enum.Font.SourceSansLight
NewGuiPart25.FontSize = Enum.FontSize.Size24
NewGuiPart25.Text = ""
NewGuiPart25.TextColor3 = Color3.new(1, 1, 1)
NewGuiPart25.TextWrapped = true
NewGuiPart25.Parent = NewGuiPart21
-------
local NewGuiPart26 = Instance.new("Sound")
NewGuiPart26.Parent = NewGuiPart21
NewGuiPart26.SoundId = "rbxassetid://1570673370"
NewGuiPart26.Name = "ErrorSound"
end

CreateGUI()

--//Variables
local Linx = game.Players.LocalPlayer.PlayerGui.Linx
local MainFrame = Linx.MainFrame
local HeaderMain = MainFrame.HeaderFrame
local ServerTab = MainFrame.ServerTab
local SpawnerTab = MainFrame.SpawnerTab
local MiscellaneousTab = MainFrame.MiscellaneousTab
local SettingsTab = MainFrame.SettingsTab
local Name = ServerTab.NameBox
local Prefix = SettingsTab.PrefixBox

--//Functions
HeaderMain.TabFrame.Server.MouseButton1Click:Connect(function()
    ServerTab.Visible = true
    SpawnerTab.Visible = false
    MiscellaneousTab.Visible = false
    SettingsTab.Visible = false
end)

HeaderMain.TabFrame.Spawner.MouseButton1Click:Connect(function()
    ServerTab.Visible = false
    SpawnerTab.Visible = true
    MiscellaneousTab.Visible = false
    SettingsTab.Visible = false
end)

HeaderMain.TabFrame.Miscellaneous.MouseButton1Click:Connect(function()
    ServerTab.Visible = false
    SpawnerTab.Visible = false
    MiscellaneousTab.Visible = true
    SettingsTab.Visible = false
end)

HeaderMain.TabFrame.Settings.MouseButton1Click:Connect(function()
    ServerTab.Visible = false
    SpawnerTab.Visible = false
    MiscellaneousTab.Visible = false
    SettingsTab.Visible = true
end)

HeaderMain.CloseButton.MouseButton1Click:Connect(function()
    Linx:Destroy()
end)

ServerTab.LagButton.MouseButton1Click:Connect(function()
    if game.Players[Name.Text].Character:FindFirstChild("Ak47u") then
        while true do
            game.Players[Name.Text].Character.Ak47u.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Ruger") then
        while true do
            game.Players[Name.Text].Character.Ruger.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Glock") then
        while true do
            game.Players[Name.Text].Character.Glock.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("M1911") then
        while true do
            game.Players[Name.Text].Character.M1911.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Deagle") then
        while true do
            game.Players[Name.Text].Character.Deagle.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Rossi") then
        while true do
            game.Players[Name.Text].Character.Rossi.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("GoldAk") then
        while true do
            game.Players[Name.Text].Character.GoldAk.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("GoldDeagle") then
        while true do
            game.Players[Name.Text].Character.GoldDeagle.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("GoldRossi") then
        while true do
            game.Players[Name.Text].Character.GoldRossi.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Mp5") then
        while true do
            game.Players[Name.Text].Character.Mp5.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Tec9") then
        while true do
            game.Players[Name.Text].Character.Tec9.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Mac10") then
        while true do
            game.Players[Name.Text].Character.Mac10.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("AkBlade") then
        while true do
            game.Players[Name.Text].Character.AkBlade.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Taser") then
        while true do
            game.Players[Name.Text].Character.Taser.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("PDGlock") then
        while true do
            game.Players[Name.Text].Character.PDGlock.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("USP45") then
        while true do
            game.Players[Name.Text].Character.USP45.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("Remington") then
        while true do
            game.Players[Name.Text].Character.Remington.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("PurpleGun") then
        while true do
            game.Players[Name.Text].Character.PurpleGun.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("GlockDrum") then
        while true do
            game.Players[Name.Text].Character.GlockDrum.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("AkDrum") then
        while true do
            game.Players[Name.Text].Character.AkDrum.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("GlockBeam") then
        while true do
            game.Players[Name.Text].Character.GlockBeam.ClipDrop:FireServer()
            wait()
        end
    elseif game.Players[Name.Text].Character:FindFirstChild("M1911Silenced") then
        while true do
            game.Players[Name.Text].Character.M1911Silenced.ClipDrop:FireServer()
            wait()
        end
    end
end)

ServerTab.KillButton.MouseButton1Click:Connect(function()
    local Descendants = game:GetDescendants()
    for index, Descendants in pairs(Descendants) do
        if Descendants:IsA("RemoteEvent") and Descendants.Name == "Damage" then
            Descendants:FireServer(game.Players[Name.Text].Character.Humanoid, math.huge, game.Players[Name.Text].Character)
            wait()
            Descendants:FireServer(game.Players[Name.Text].Character.Humanoid, math.huge, game.Players[Name.Text].Character)
        end
    end
end)

ServerTab.GodButton.MouseButton1Click:Connect(function()
    local Descendants = game:GetDescendants()
    for index, Descendants in pairs(Descendants) do
        if Descendants:IsA("RemoteEvent") and Descendants.Name == "Damage" then
        while true do
            Descendants:FireServer(game.Players[Name.Text].Character.Humanoid, -math.huge, game.Players[Name.Text].Character)
            wait()
            end
        end
    end
end)